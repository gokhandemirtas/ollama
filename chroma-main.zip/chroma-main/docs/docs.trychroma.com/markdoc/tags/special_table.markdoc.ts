import { SpecialTable } from "../../components/markdoc/SpecialTable";

export const special_table = {
    render: SpecialTable,
    attributes: {
      label: {
        type: String
      },
    }
  };
