/* Use this file to export your markdoc tags */
export * from './tabs.markdoc'
export {note, br, math} from './note.markdoc';
export {special_table} from './special_table.markdoc';
export {codetabs, codetab} from './codetabs.markdoc';
