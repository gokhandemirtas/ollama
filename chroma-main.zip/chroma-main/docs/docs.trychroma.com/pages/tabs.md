---
title: Tabs demo
---


{% tabs %}

{% tab label="React" %}
React content goes here huh
{% /tab %}

{% tab label="HTML" %}
HTML content goes here ok
{% /tab %}

{% /tabs %}


{% tabs %}

{% tab label="california" %}
ca babyyy
{% /tab %}

{% tab label="newyork" %}
nyc babyyy
{% /tab %}

{% /tabs %}


***

{% tabs group="code-lang" %}

{% tab label="Python" %}
22 python
{% /tab %}

{% tab label="Javascript" %}
22 javascript
{% /tab %}

{% /tabs %}

{% tabs group="code-lang" %}

{% tab label="Python" %}
22 python
{% /tab %}

{% tab label="Javascript" %}
22 javascript
{% /tab %}

{% /tabs %}
