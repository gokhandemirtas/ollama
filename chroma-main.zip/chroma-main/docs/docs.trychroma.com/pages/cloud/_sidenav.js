
export const items = [
    {
        title: 'Cloud',
        links: [
          { href: '/cloud/teams', children: 'Teams' },
          { href: '/cloud/apikeys', children: 'API Keys' },
          { href: '/cloud/performance', children: 'Performance' },
        ]
    },
  ];
