---
title: 💡 Examples
---

This section contains a growing set of examples.

Examples listed here are 1st class citizens in the documentation. They are tested, maintained and updated as the library evolves. Walkthroughs are designed to go step by step.


{% special_table %}
{% /special_table %}

|              |  | Python | JS |
|--------------|-----------|---------------|--|
| [🖼️ Multimodal](/examples/multimodal) | Embed and retrieve images | ✅  | ➖ |
| 🚧 *More Coming Soon* | |  | |
