export const items = [
    {
      title: 'Examples',
      links: [
        // { href: '/examples/documents', children: 'Q&A over Documents' },
        // { href: '/examples/code', children: 'Q&A over Code' },
        { href: '/examples/multimodal', children: '🖼️ Multimodal' },
        // { href: '/examples/agents', children: 'Agents' },
      ]
    },
    // {
    //   title: 'Frameworks',
    //   links: [
    //     { href: '/examples/nextjs', children: 'NextJS' },
    //     { href: '/examples/rails', children: 'Rails' },
    //     { href: '/examples/fastapi', children: 'FastAPI' },
    //   ]
    // },

  ];
