---
title: 🦙 LlamaIndex
---

- `LlamaIndex` [Vector Store page](https://docs.llamaindex.ai/en/stable/examples/vector_stores/ChromaIndexDemo.html)
- [Demo](https://github.com/run-llama/llama_index/blob/main/docs/docs/examples/data_connectors/ChromaDemo.ipynb)
- [Chroma Loader on Llamahub](https://llamahub.ai/l/vector_stores/llama-index-vector-stores-chroma)
