export function SpecialTable() {
    return <div className="special_table"></div>
  }
